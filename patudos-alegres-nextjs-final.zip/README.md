# Patudos Alegres — Next.js

Conversão fiel do HTML original para Next.js. O layout, textos, cores, imagens, links e estrutura visual foram preservados. O JavaScript legado do menu foi substituído por React sem alterar o design.

## Rodar

```bash
npm install
npm run dev
```

Abra http://localhost:3000

## Produção

```bash
npm run build
npm start
```
